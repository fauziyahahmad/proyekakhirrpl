<?php
    
    session_start();

$query=new mysqli('localhost','root','','projek_rpl');

$email_ustaz = $_POST['email_ustaz'];
$pw_ustaz = $_POST['pw_ustaz'];

$data = mysqli_query($query, "select *from ustaz where email_ustaz='$email_ustaz' and pw_ustaz='$pw_ustaz' ")
        or die(mysqli_error($query));

$row = mysqli_fetch_object($data);

$cek = mysqli_num_rows($data);

if($cek > 0)
{
    $id_ustaz = $row->id_ustaz;
    $_SESSION['id_ustaz'] = $id_ustaz;
    $_SESSION['email_ustaz'] = $email_ustaz;
    $_SESSION['status'] = "login";
    header("location:useru/index.php");
}
else 
{
    header("location:login_u.php?pesan=gagal");
}

?>