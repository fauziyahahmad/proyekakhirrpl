<?php 

	$localhost = "localhost";
	$user = "root";
	$pass = "";
	$database = "projek_rpl";

	$koneksi = mysqli_connect($localhost,$user,$pass,$database);

?>