<?php

include "koneksi.php";


$koneksi=new mysqli('localhost','root','','projek_rpl');

$nama_pemohon = $_POST['nama_pemohon'];
$email_pemohon = $_POST['email_pemohon'];
$pw_pemohon = $_POST['pw_pemohon'];
$jk_pemohon = $_POST['jk_pemohon'];
$alamat_pemohon = $_POST['alamat_pemohon'];
$nohp_pemohon = $_POST['nohp_pemohon'];

$query= mysqli_query($koneksi, "insert into pemohon values('', '$pw_pemohon', '$nama_pemohon', '$jk_pemohon', '$alamat_pemohon', '$nohp_pemohon' , '$email_pemohon')") 
        or die(mysqli_error($koneksi));

$query2 = mysqli_query($koneksi, "select *from pemohon where email_pemohon='$email_pemohon' and pw_pemohon='$pw_pemohon' ")
        or die(mysqli_error($koneksi));

$row = mysqli_fetch_object($query2);

if ($query)
{
    session_start();
    $id_pemohon = $row->id_pemohon;
    $_SESSION['id_pemohon'] = $id_pemohon;
    $_SESSION['email_pemohon'] = $email_pemohon;
    $_SESSION['status'] = "login";
   header("location:userp/index.php");
}
else
{
    echo "Ups...gagal";
}
?>
