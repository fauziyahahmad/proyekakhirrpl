<?php

include "koneksi.php";


$koneksi=new mysqli('localhost','root','','projek_rpl');

$nama_ustaz = $_POST['nama_ustaz'];
$email_ustaz = $_POST['email_ustaz'];
$pw_ustaz = $_POST['pw_ustaz'];
$jk_ustaz = $_POST['jk_ustaz'];
$alamat_ustaz = $_POST['alamat_ustaz'];
$nohp_ustaz = $_POST['nohp_ustaz'];

$query= mysqli_query($koneksi, "insert into ustaz values('', '$pw_ustaz', '$nama_ustaz', '$jk_ustaz', '$alamat_ustaz', '$nohp_ustaz' , '$email_ustaz')") 
        or die(mysqli_error($koneksi));

$query2 = mysqli_query($koneksi, "select *from ustaz where email_ustaz='$email_ustaz' and pw_ustaz='$pw_ustaz' ")
        or die(mysqli_error($koneksi));

$row = mysqli_fetch_object($query2);

if ($query)
{
    session_start();
    $id_ustaz = $row->id_ustaz;
    $_SESSION['id_ustaz'] = $id_ustaz;
    $_SESSION['email_ustaz'] = $email_ustaz;
    $_SESSION['status'] = "login";
   header("location:useru/index.php");
}
else
{
    echo "Ups...gagal";
}
?>
