 <?php 
	session_start();
    if(empty($_SESSION['email_pemohon']))
	{
		header("location:../index.php?pesan=belum_login");
	}
	?>

    <!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>invitUst</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/jquery-ui.css">				
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">				
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>	
            
          
			<header id="header">
				<div class="container main-menu">
					<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo ">
				        <a href="index.php" class="text-black"><h3><img src="img/gambar30.png" alt="" title="" />invitUst</h3></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li><a href="index.php">Pengajuan</a></li>
				          <li><a href="riwayat.php">Riwayat</a></li>
                            <li><a href="profil.php">Profil</a></li>
                          <li><a href="logout.php">Logout</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->					      		  
					</div>
				</div>
			</header><!-- #header -->
			
			<!-- start banner Area -->
			<section class="banner-area relative">			
				<div class="container">
					<div class="row fullscreen align-items-center justify-content-between">
						<div class="col-lg-6 col-md-6 banner-left">
							<h1 class="text-white">Undang</h1>
                            <p class="text-white">
								Silakan mengisi form berikut untuk mengundang Ustaz
							</p>
						</div>
                        
                        
       <?php
	include "koneksi.php";
	$id_ustaz = $_GET['id'];
    $id_pemohon = $_SESSION['id_pemohon'];
	$query = mysqli_query($koneksi,"select * from ustaz where id_ustaz='$id_ustaz'");                  
	$row =  mysqli_fetch_object($query);

		?>
						<div class="col-lg-4 col-md-6 banner-right">
							<ul class="nav nav-tabs" id="myTab" role="tablist">
							  <li class="nav-item">
							    <a class="nav-link active" id="flight-tab" data-toggle="tab" href="#flight" role="tab" aria-controls="flight" aria-selected="true">Ajukan Permohonan</a>
							  </li>
							</ul>
							<div class="tab-content" id="myTabContent">
							  <div class="tab-pane fade show active" id="flight" role="tabpanel" aria-labelledby="flight-tab">
                                  
								<form method="POST" class="form-wrap" action="proses_p.php">
                                    
                                    <b>Ustaz <?= $row->nama_ustaz; ?></b>
                                    
                                    <input type="hidden" name="id_ustaz" value="<?= $row->id_ustaz; ?>">
                                    
									<input type="text" class="form-control" name="nama_acara" placeholder="Nama Acara " onfocus="this.placeholder = ''" onblur="this.placeholder = 'Nama Acara '">									
									<input type="text" class="form-control" name="tema_acara" placeholder="Tema Acara " onfocus="this.placeholder = ''" onblur="this.placeholder = 'Tema Acara '">
                                    
                                    <input type="text" class="form-control" name="tempat_acara" placeholder="Tempat Acara " onfocus="this.placeholder = ''" onblur="this.placeholder = 'Tempat Acara '">
                                    
									<input type="text" class="form-control date-picker" name="tanggal_acara" placeholder="Tanggal Acara " onfocus="this.placeholder = ''" onblur="this.placeholder = 'Tanggal Acara '">
                                    
                                    <input type="text" class="form-control" name="waktu_acara" placeholder="Waktu Acara " onfocus="this.placeholder = ''" onblur="this.placeholder = 'Waktu Acara '">
                                    
                                    <input type="hidden" name="status" value="Proses">
                                    
                                    <input class="primary-btn text-uppercase" type="submit" name="submit" value="SUBMIT">
                                    
								</form>
							  </div>
                              
							</div>
						</div>
					</div>
				</div>					
			</section>
			<!-- End banner Area -->

			
			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="js/popper.min.js"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>		
 			<script src="js/jquery-ui.js"></script>					
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>					
			<script src="js/owl.carousel.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>