<?php 
	session_start();
    if(empty($_SESSION['email_pemohon']))
	{
		header("location:../index.php?pesan=belum_login");
	}
	?>

    <!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
        
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>invitUst</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/jquery-ui.css">				
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">				
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>	
            
    
<?php
include "koneksi.php";
$id_pemohon = $_SESSION['id_pemohon'];
$query=mysqli_query($koneksi, "Select * from pemohon where id_pemohon='$id_pemohon'")or die(mysqli_error($koneksi));
$row=mysqli_fetch_object($query);
 ?>
			<header id="header">
				<div class="container main-menu">
					<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo ">
				        <a href="index.php" class="text-black"><h3><img src="img/gambar30.png" alt="" title="" />invitUst</h3></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
                          <li><a href="index.php">Pengajuan</a></li>
				          <li><a href="riwayat.php">Riwayat</a></li>
                            <li><a href="profil.php">Profil</a></li>
                          <li><a href="logout.php">Logout</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->					      		  
					</div>
				</div>
			</header><!-- #header -->
            
			<!-- start banner Area -->
			<section class="about-banner relative">
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Edit Profil Pemohon			
							</h1>	
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->
            
            <!-- Start destinations Area -->
			<section class="destinations-area ">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-7">
							<div class="single-destinations">
								<div class="details">
									<h4>Halo, <?= $row->nama_pemohon; ?>!</h4>
									<p>
										Role: Pemohon
									</p>
                                    
                                    <form method="POST" class="form-wrap" action="updateprofil_p.php">
                                        <input type="hidden" name="id_pemohon" value="<?= $row->id_pemohon; ?>">
									<ul class="package-list">
                                        
										<li class="d-flex justify-content-between align-items-center">
											<span>Nama</span>
											<span><input type="text" name="nama_pemohon" value="<?= $row->nama_pemohon; ?>"></span>
										</li>
										<li class="d-flex justify-content-between align-items-center">
											<span>Email</span>
											<span><input type="text" name="email_pemohon" value="<?= $row->email_pemohon; ?>"></span>
										</li>
                                        <li class="d-flex justify-content-between align-items-center">
											<span>Password</span>
											<span><input type="password" name="pw_pemohon" value="<?= $row->pw_pemohon; ?>"></span>
										</li>
										<li class="d-flex justify-content-between align-items-center">
											<span>Jenis Kelamin</span>
											<span><input type="text" name="jk_pemohon" value="<?= $row->jk_pemohon; ?>"readonly></span>
										</li>
										<li class="d-flex justify-content-between align-items-center">
											<span>Alamat</span>
											<span><input type="text" name="alamat_pemohon" value="<?= $row->alamat_pemohon; ?>"></span>
										</li>
                                        <li class="d-flex justify-content-between align-items-center">
											<span>Nomor HP</span>
											<span><input type="text" name="nohp_pemohon" value="<?= $row->nohp_pemohon; ?>"></span>
										</li>
                                        
										<li class="d-flex justify-content-between align-items-center">
                                            <span></span>
											<span><input class="price-btn" type="submit" name="submit" value="SUBMIT"></span>
										</li>	
									</ul>
                                    </form>
								</div>
							</div>
						</div>																														
					</div>
                    
                    
				</div>	
			</section>
			<!-- End destinations Area -->

			
			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="js/popper.min.js"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>		
 			<script src="js/jquery-ui.js"></script>					
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>					
			<script src="js/owl.carousel.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
            
            
		</body>
	</html>