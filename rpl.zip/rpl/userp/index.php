<?php 
	session_start();
    if(empty($_SESSION['email_pemohon']))
	{
		header("location:../index.php?pesan=belum_login");
	}
	?>

<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>invitUst</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/jquery-ui.css">				
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">				
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>
            
            <?php
include "koneksi.php";
$query=mysqli_query($koneksi, "Select *from ustaz");
 ?>
			<header id="header">
				<div class="container main-menu">
					<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo ">
				        <a href="index.php" class="text-black"><h3><img src="img/gambar30.png" alt="" title="" />invitUst</h3></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li><a href="index.php">Pengajuan</a></li>
				          <li><a href="riwayat.php">Riwayat</a></li>
                            <li><a href="profil.php">Profil</a></li>
                          <li><a href="logout.php">Logout</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->					      		  
					</div>
				</div>
			</header><!-- #header -->
			
			

			<!-- Start price Area -->
			<section class="price-area section-gap">
                <div class="overlay overlay-bg"></div>	
				<div class="container">
		            <div class="row d-flex justify-content-center">
		                <div class="menu-content pb-70 col-lg-8">
		                    <div class="title text-center">
		                        <h1 class="text-white">Silakan pilih Ustaz yang ingin Anda undang!</h1>
		                    </div>
		                </div>
		            </div>		
                    
					<div class="row">
                    <?php
                    while($row=mysqli_fetch_object($query))
                    {
                    ?>  
						
                        <br><div class="col-lg-4">
							<div class="single-price">
								<h4><?= $row->nama_ustaz; ?></h4>
								<ul class="price-list">
									<li class="d-flex justify-content-between align-items-center">
										<span><?= $row->email_ustaz; ?></span>
										<a href="add_p.php?id=<?= $row->id_ustaz; ?>" class="price-btn">Undang</a>
									</li>											
								</ul>
							</div>
						</div>
						<?php } ?>											
					</div>
				</div>	
			</section>
			<!-- End price Area -->
			


			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="js/popper.min.js"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>		
 			<script src="js/jquery-ui.js"></script>					
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>					
			<script src="js/owl.carousel.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>