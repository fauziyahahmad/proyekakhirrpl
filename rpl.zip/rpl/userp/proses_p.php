<?php 
	include "koneksi.php";

    session_start();
if(empty($_SESSION['email_pemohon']))
	{
		header("location:../index.php?pesan=belum_login");
	}

    $id_pemohon = $_SESSION['id_pemohon'];
    $id_ustaz = $_POST['id_ustaz'];
    $nama_acara = $_POST['nama_acara'];
    $tema_acara = $_POST['tema_acara'];
    $tempat_acara = $_POST['tempat_acara'];
    $tanggal_acara = $_POST['tanggal_acara'];
    $waktu_acara = $_POST['waktu_acara'];
    $status = $_POST['status'];

	$query = mysqli_query($koneksi, "INSERT INTO permohonan values('', '$id_pemohon', '$id_ustaz', '$nama_acara', '$tema_acara', '$tempat_acara', '$tanggal_acara', '$waktu_acara', '$status')") or die(mysqli_error($koneksi));

	if ($query) {
		header("location:riwayat.php");
	}
	else{
		print "Gagal";
	}

 ?>