<?php

include "koneksi.php";

session_start();
if(empty($_SESSION['email_pemohon']))
	{
		header("location:../index.php?pesan=belum_login");
	}

$id_pemohon = $_POST['id_pemohon'];
$pw_pemohon = $_POST['pw_pemohon'];
$nama_pemohon = $_POST['nama_pemohon'];
$email_pemohon = $_POST['email_pemohon'];
$jk_pemohon = $_POST['jk_pemohon'];
$alamat_pemohon = $_POST['alamat_pemohon'];
$nohp_pemohon = $_POST['nohp_pemohon'];

$query= mysqli_query($koneksi, "update pemohon set pw_pemohon='$pw_pemohon', nama_pemohon='$nama_pemohon', alamat_pemohon='$alamat_pemohon',nohp_pemohon='$nohp_pemohon',email_pemohon='$email_pemohon' where id_pemohon='$id_pemohon' ") 
        or die(mysqli_error($koneksi));

header("location:profil.php");
?>