<?php
    include "koneksi.php";

session_start();
if(empty($_SESSION['email_ustaz']))
	{
		header("location:../index.php?pesan=belum_login");
	}

    $id_acara = $_GET['id'];
    $query=mysqli_query($koneksi,"DELETE FROM permohonan where id_acara='$id_acara' ");

if($query)
{
    
    header("location:index.php");
    echo "<script>alert('Acara berhasil dihapus');</script>";
}
else
{
    echo "Proses hapus gagal";  
}

?>