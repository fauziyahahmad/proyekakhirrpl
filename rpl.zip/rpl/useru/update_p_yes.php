<?php

include "koneksi.php";

session_start();
if(empty($_SESSION['email_ustaz']))
	{
		header("location:../index.php?pesan=belum_login");
	}

$id_acara = $_GET['id'];

$query= mysqli_query($koneksi, "update permohonan set status='Diterima' where id_acara='$id_acara'") 
        or die(mysqli_error($koneksi));

if ($query)
{
    
    header("location:index.php");
}
else
{
    echo "Gagal";
}

?>