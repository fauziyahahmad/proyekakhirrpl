<?php

include "koneksi.php";

session_start();
if(empty($_SESSION['email_ustaz']))
	{
		header("location:../index.php?pesan=belum_login");
	}

$id_ustaz = $_POST['id_ustaz'];
$pw_ustaz = $_POST['pw_ustaz'];
$nama_ustaz = $_POST['nama_ustaz'];
$email_ustaz = $_POST['email_ustaz'];
$jk_ustaz = $_POST['jk_ustaz'];
$alamat_ustaz = $_POST['alamat_ustaz'];
$nohp_ustaz = $_POST['nohp_ustaz'];

$query= mysqli_query($koneksi, "update ustaz set pw_ustaz='$pw_ustaz', nama_ustaz='$nama_ustaz', alamat_ustaz='$alamat_ustaz',nohp_ustaz='$nohp_ustaz',email_ustaz='$email_ustaz' where id_ustaz='$id_ustaz' ") 
        or die(mysqli_error($koneksi));

header("location:profil.php");
?>